package com.example.address_book_application;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class Datamanager {

    private SQLiteDatabase db;


    public Datamanager(Context context) {
        MySQLiteOpenHelper helper = new MySQLiteOpenHelper(context);
        db = helper.getWritableDatabase();
    }

    public Cursor selectAll() {

        Cursor cursor = null;

        try {
            String query = "select * from contact";
            cursor = db.rawQuery(query, null);
            //Log.i ("info", "In Datamanager selectAll try statement");
        } catch (Exception e) {
            Log.i("info", "In DataManager selectAll method");
            Log.i("info", e.getMessage());
        }

        Log.i("info", "Loaded data " + cursor.getCount());
        return cursor;
    }


    public boolean updateContactDatamanager(int id, String name, String phone, String email, String address,
                              String facebook, String city, String state, String zip, String contacttype) {



        ContentValues contentValues=new ContentValues();


        contentValues.put("id",id);
        contentValues.put("name",name);
        contentValues.put("phone",phone);
        contentValues.put("email",email);
        contentValues.put("address",address);
        contentValues.put("facebook",facebook);
        contentValues.put("city",city);
        contentValues.put("state",state);
        contentValues.put("zip",zip);
        contentValues.put("phone",contacttype);

        db.update("contact",contentValues,"id=?",new String[]{String.valueOf(id)});


        return true;



//        try{
//            String query = "update  contact"
//
//            db.execSQL(query);
//
//
//
//        }
//        catch (SQLException e) {
//            Log.i ("info", "In DataManager update method");
//            Log.i ("info", e.getMessage());
//        }
//        Log.i ("info", "updated  contact " + name);
//    }
//


    }

    public void insert(String name, String phone, String email, String address,
                       String facebook, String city, String state, String zip, String contacttype) {

        try {
            String query = "insert into contact" +
                    "(name, phone, email, address,facebook, city, state, zip, contacttype) values " +
                    "( '" + name + "', '" + phone + "', '" + email + "', '" + address + "','" + facebook + "', '" + city +
                    "', '" + state + "', '" + zip + "', '" + contacttype + "' )";
            db.execSQL(query);
        } catch (SQLException e) {
            Log.i("info", "In DataManager insert method");
            Log.i("info", e.getMessage());
        }
        Log.i("info", "Added new contact " + name);
    }

    private class MySQLiteOpenHelper extends SQLiteOpenHelper {

        /**
         * Constructor os used to initialize the database name, and version number
         *
         * @param context
         */
        public MySQLiteOpenHelper(Context context) {
            super(context, "address_book", null, 1);

        }


        @Override
        public void onCreate(SQLiteDatabase db) {

            try {
                String newTable = "create table contact ("
                        + "_id integer primary key autoincrement not null, "
                        + "name text not null, "
                        + "phone text, "
                        + "email text, "
                        + "address text, "
                        + "facebook text, "
                        + "city text, "
                        + "state text, "
                        + "zip text, "
                        + "contacttype)";

                db.execSQL(newTable);
            } catch (SQLException e) {
                Log.i("info", "In DataManager onCreate method");
                Log.i("info", e.getMessage());
            }


        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        }
    }
}

