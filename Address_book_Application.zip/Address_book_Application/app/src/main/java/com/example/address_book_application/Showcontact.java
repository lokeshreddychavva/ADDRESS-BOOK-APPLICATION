package com.example.address_book_application;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.DialogFragment;

public class Showcontact extends DialogFragment {

    private TextView showname;
    private TextView showphone;
    private TextView showemail;
    private TextView showaddress;
    private TextView showfacebook;
    private TextView showcity;
    private TextView showstate;
    private TextView showzip;
    private TextView showcontacttype;
    private Button buttonmainmenu;

    private Contact contact;

    public Dialog OncreateDialog (Bundle savedInstancesave){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater infalter = getActivity().getLayoutInflater();

        View dialogView = infalter.inflate(R.layout.view_contact, null);

        showname=dialogView.findViewById(R.id.viewnameid);
        showphone=dialogView.findViewById(R.id.viewphoneid);
        showemail=dialogView.findViewById(R.id.viewemailid);
        showaddress=dialogView.findViewById(R.id.viewaddressid);
        showfacebook=dialogView.findViewById(R.id.viewfacebookid);
        showcity=dialogView.findViewById(R.id.viewcityid);
        showstate=dialogView.findViewById(R.id.viewstateid);
        showzip=dialogView.findViewById(R.id.viewzipid);
        showcontacttype=dialogView.findViewById(R.id.viewcontactType);
        buttonmainmenu=dialogView.findViewById(R.id.viewmainmenu);


        showname.setText(contact.getName());
        showphone.setText(contact.getPhone());
        showemail.setText(contact.getEmail());
        showaddress.setText(contact.getAddress());
        showfacebook.setText(contact.getFacebook());
        showcity.setText(contact.getCity());
        showstate.setText(contact.getState());
        showzip.setText(contact.getZip());
        showcontacttype.setText(contact.getContacttype());



        builder.setView(dialogView).setMessage("");

        buttonmainmenu.setOnClickListener( new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

        return builder.create();




    }

    public void sendSelectedContacttolist (Contact contact) {
        this.contact = contact;
    }

    public void sendSelectedContact(Contact contact) {
        this.contact = contact;
    }
}
